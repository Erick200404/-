import pandas as pd
import random
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import skew, kurtosis
import seaborn as sns

#读取数据
df_1 = pd.read_excel("E:\数据科学\\2023年秋数据科学导论大作业数据\附件3_项目三数据集\附件1.xlsx")
df_2 = pd.read_excel("E:\数据科学\\2023年秋数据科学导论大作业数据\附件3_项目三数据集\附件2.xlsx")
df_3 = pd.read_excel("E:\数据科学\\2023年秋数据科学导论大作业数据\附件3_项目三数据集\附件3.xlsx")
df_4 = pd.read_excel("E:\\数据科学\\2023年秋数据科学导论大作业数据\\附件3_项目三数据集\\附件4.xlsx",sheet_name='Sheet1')

'''
# 检查缺失值
print(df_1.isnull().sum())  # 显示每列缺失值的数量
print(df_2.isnull().sum())
print(df_3.isnull().sum())
print(df_4.isnull().sum())
#无缺失值
'''

'''
#检验数据是否导入
print(df_1.head())
print(df_2.head())
print(df_3.head())
print(df_4.head())
'''
'''
#分类
df_1_pl1 = df_1[df_1['分类编码']==1011010101]
df_1_pl2 = df_1[df_1['分类编码']==1011010201]
df_1_pl3 = df_1[df_1['分类编码']==1011010402]
df_1_pl4 = df_1[df_1['分类编码']==1011010501]
df_1_pl5 = df_1[df_1['分类编码']==1011010504]
df_1_pl6 = df_1[df_1['分类编码']==1011010801]
'''
'''
#检验是否成功分类
print(df_1_pl1.head())
print(df_1_pl2.head())
print(df_1_pl3.head())
print(df_1_pl4.head())
print(df_1_pl5.head())
print(df_1_pl6.head())
'''
#print(df_4.head())

# 合并两个文件
merged_data = pd.merge(df_2, df_1, how='left', on='单品编码')

#merged_data_123 = pd.merge(merged_data, df_3, how='left', on=['销售日期','单品编码'])

#merged_data_1234 = pd.merge(merged_data_123, df_4, how='left', on=['单品编码'])

# 打印结果
#print(merged_data_1234.head())

# 输出文件
#merged_data_123.to_excel('E:\\数据科学\\2023年秋数据科学导论大作业数据\\附件3_项目三数据集\\merged_data_123.xlsx', index=False)

#merged_data_1234.to_excel('E:\\数据科学\\2023年秋数据科学导论大作业数据\\附件3_项目三数据集\\merged_data_1234.xlsx', index=False)
'''
# 按单品名称分组，计算销售量总和
sales_by_product = merged_data.groupby('单品编码')['销量(千克)'].sum().reset_index()

# 打印结果
#print(sales_by_product)

# 定义每个层次需要抽取的样本数量
samples_per_stratum = {'low': 2, 'medium': 2, 'high': 2}

# 将销量分成三个层次
sales_by_product['销量层次'] = pd.qcut(sales_by_product['销量(千克)'], q=[0, 1/3, 2/3, 1], labels=['low', 'medium', 'high'])

# 执行分层抽样
sampled_data = []
for stratum, count in samples_per_stratum.items():
    stratum_data = sales_by_product[sales_by_product['销量层次'] == stratum]
    sampled_data.extend(random.sample(stratum_data['单品编码'].tolist(), count))

print("抽样结果:", sampled_data)


# 定义导出路径
output_path = 'E:\\数据科学\\2023年秋数据科学导论大作业数据\\附件3_项目三数据集\\'

# 遍历不同分层的数据，并导出到不同的 Excel 文件
for i, bianma in enumerate(sampled_data):
    file_name = f'merged_data_danpin_{i}.xlsx'  # 根据分层名称生成文件名

    # 获取对应分层的数据
    stratum_data = merged_data[merged_data['单品编码'] == bianma]

    # 导出到 Excel 文件
    stratum_data.to_excel(output_path + file_name, index=False)
'''

# 分类
merged_data_pl1_huaye = merged_data[merged_data['分类编码'] == 1011010101]
merged_data_pl2_huacai = merged_data[merged_data['分类编码'] == 1011010201]
merged_data_pl3_ssgj = merged_data[merged_data['分类编码'] == 1011010402]
merged_data_pl4_qie = merged_data[merged_data['分类编码'] == 1011010501]
merged_data_pl5_lajiao = merged_data[merged_data['分类编码'] == 1011010504]
merged_data_pl6_shiyongjun = merged_data[merged_data['分类编码'] == 1011010801]
'''
# 检查正确性
print(merged_data_pl1_huaye.head())
print(merged_data_pl2_huacai.head())
print(merged_data_pl3_ssgj.head())
print(merged_data_pl4_qie.head())
print(merged_data_pl5_lajiao.head())
print(merged_data_pl6_shiyongjun.head())
'''
'''
# 输出文件
merged_data_pl1_huaye.to_excel('E:\\数据科学\\2023年秋数据科学导论大作业数据\\附件3_项目三数据集\\merged_data_pl1_huaye.xlsx', index=False)
merged_data_pl2_huacai.to_excel('E:\\数据科学\\2023年秋数据科学导论大作业数据\\附件3_项目三数据集\\merged_data_pl2_huacai.xlsx', index=False)
merged_data_pl3_ssgj.to_excel('E:\\数据科学\\2023年秋数据科学导论大作业数据\\附件3_项目三数据集\\merged_data_pl3_ssgj.xlsx', index=False)
merged_data_pl4_qie.to_excel('E:\\数据科学\\2023年秋数据科学导论大作业数据\\附件3_项目三数据集\\merged_data_pl4_qie.xlsx', index=False)
merged_data_pl5_lajiao.to_excel('E:\\数据科学\\2023年秋数据科学导论大作业数据\\附件3_项目三数据集\\merged_data_pl5_lajiao.xlsx', index=False)
merged_data_pl6_shiyongjun.to_excel('E:\\数据科学\\2023年秋数据科学导论大作业数据\\附件3_项目三数据集\\merged_data_pl6_shiyongjun.xlsx', index=False)
'''

# 创建数据框列表
categories = [merged_data_pl1_huaye, merged_data_pl2_huacai, merged_data_pl3_ssgj,
              merged_data_pl4_qie, merged_data_pl5_lajiao, merged_data_pl6_shiyongjun]

# 创建一个空的数据框以存储统计量
statistics_df = pd.DataFrame(columns=['类别', '均值', '中位数', '标准差', '最小值', '最大值', '变异系数', '偏度', '峰度'])

# 循环遍历每个类别
for category_df in categories:
    # 按销售日期分组并计算每天的销售总量
    daily_sales = category_df.groupby('销售日期')['销量(千克)'].sum()

    # 计算统计量
    mean_value = np.mean(daily_sales)
    median_value = np.median(daily_sales)
    std_dev = np.std(daily_sales)
    min_value = np.min(daily_sales)
    max_value = np.max(daily_sales)

    # 变异系数
    coefficient_of_variation = std_dev / mean_value

    # 偏度和峰度
    skewness = skew(daily_sales)
    kurt = kurtosis(daily_sales)

    new_row = pd.DataFrame(
        {'类别': [category_df['分类编码'].iloc[0]], '均值': [mean_value], '中位数': [median_value], '标准差': [std_dev], '最小值': [min_value],
         '最大值': [max_value], '变异系数': [coefficient_of_variation], '偏度': [skewness], '峰度': [kurt]})
    statistics_df = pd.concat([statistics_df, new_row], ignore_index=True)

# 打印统计量数据框
print(statistics_df)
statistics_df.to_excel('E:\\数据科学\\2023年秋数据科学导论大作业数据\\附件3_项目三数据集\\statistics_df.xlsx', index=False)


'''
#测试
merged_data_pl1_huaye_shq = merged_data_pl1_huaye[merged_data_pl1_huaye['单品编码'] == 102900005115823]
#merged_data_pl1_huaye_shq = merged_data_pl1_huaye
#print(merged_data_pl1_huaye_shq.haed())

merged_data_pl1_huaye_shq = merged_data_pl1_huaye_shq[merged_data_pl1_huaye_shq['销售类型'] == '销售']
merged_data_pl1_huaye_shq = merged_data_pl1_huaye_shq[merged_data_pl1_huaye_shq['销售日期'] == '2020-07-01']
# 将日期和时间列转换为时间序列
#merged_data_pl1_huaye_shq.loc[:, '销售日期'] = pd.to_datetime(merged_data_pl1_huaye_shq['销售日期'])
merged_data_pl1_huaye_shq['销售日期'] = pd.to_datetime(merged_data_pl1_huaye_shq['销售日期'])
merged_data_pl1_huaye_shq['扫码销售时间'] = pd.to_datetime(merged_data_pl1_huaye_shq['扫码销售时间'], format="%H:%M:%S.%f")

#print(merged_data_pl1_huaye_shq)
# 删除原始的日期和时间列
#merged_data_pl1_huaye_shq = merged_data_pl1_huaye_shq.drop(['扫码销售时间'], axis=1)
#print(merged_data_pl1_huaye_shq.head())

# 根据日期对销售数据进行分组，并计算每天的销售总量
daily_sales = merged_data_pl1_huaye.groupby('销售日期')['销量(千克)'].sum()
#print(daily_sales)
'''

'''
# 基本统计量分析
summary = daily_sales.describe()
print(summary)
# 基本统计量分析
mean_value = np.mean(daily_sales)
median_value = np.median(daily_sales)
std_dev = np.std(daily_sales)
min_value = np.min(daily_sales)
max_value = np.max(daily_sales)
#变异系数
coefficient_of_variation = std_dev / mean_value
#偏度
skewness = skew(daily_sales)
#峰度
kurt = kurtosis(daily_sales)

#输出
print(mean_value)
print(median_value)
print(std_dev)
print(min_value)
print(max_value)
print(coefficient_of_variation)
print(skewness)
print(kurt)
'''
'''
# 将销售日期设置为数据框的索引
merged_data_pl1_huaye_shq.set_index('销售日期', inplace=True)

# 按照15天为周期重新取样，并计算每个周期内的销售总量
sales_15_days = merged_data_pl1_huaye_shq['销量(千克)'].resample('15D').sum()
#print(sales_15_days)
'''

'''
# 绘制销量曲线图
plt.figure(figsize=(10, 6))
plt.plot(daily_sales.index, daily_sales.values, marker='o', linestyle='-', color='b')
plt.title('Sales Curve')
plt.xlabel('Date')
plt.ylabel('Sales (kg)')
plt.grid(True)
plt.show()
'''
'''
# 绘制平滑的销量曲线图
plt.figure(figsize=(10, 6))
#plt.plot(daily_sales.index, daily_sales.values, marker='o', linestyle='-', color='b', label='原始曲线')

# 使用平滑的曲线
smoothed_sales = daily_sales.rolling(window=7).mean()  # 使用滑动平均来平滑曲线，窗口大小为7
plt.plot(smoothed_sales.index, smoothed_sales.values, linestyle='-', color='r', label='Smoothed Curve')

plt.title('Sales Curve')
plt.xlabel('Date')
plt.ylabel('Sales (kg)')
plt.grid(True)
plt.legend()  # 添加图例
plt.show()
'''

