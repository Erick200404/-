import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

Q_m = pd.read_excel("E:\数据科学\\2023年秋数据科学导论大作业数据\附件3_项目三数据集\加权平均值.xlsx")
b_m = Q_m['单品编码']
b_m = list(b_m)
b_m.sort()
Q_m = Q_m.sort_values(by='单品编码')
Q_m = list(Q_m['加权平均值'])

#print(Q_m)
#print(Q_m[1])
#print(b_m)
#print(b_m[1])

w_m = pd.read_excel("E:\数据科学\\2023年秋数据科学导论大作业数据\附件3_项目三数据集\成本加权平均值.xlsx")
w_m = w_m.sort_values(by='单品编码')
w_m =list(w_m['加权平均值'])
#print(w_m)
#print(w_m[1])

Fl_m = pd.read_excel("E:\数据科学\\2023年秋数据科学导论大作业数据\附件3_项目三数据集\kb无截距.xlsx")
FL_m = Fl_m.sort_values(by='单品编码')
F_m = list(FL_m['系数k'])
l_m = list(Fl_m['损耗率(%)'])
#print(l_m)
#print(l_m[1])
#print(F_m)
#print(F_m[1])

mc = pd.read_excel("E:\数据科学\\2023年秋数据科学导论大作业数据\附件3_项目三数据集\附件1.xlsx")

# 使用列表推导式将编码替换为名称
name_list = [mc.loc[mc['单品编码'] == code, '单品名称'].iloc[0] for code in b_m if code in mc['单品编码'].values]


def funcl(x, w, f):
    y = x * w * f
    return y

sum_1 = 0
# 初始化一个空的数据框
result_df = pd.DataFrame(columns=['单品名称', '利润', '补货量', '定价'])

for a in range(30):
    Q = Q_m[a]
    w = w_m[a]
    F = F_m[a]
    l = l_m[a]/100
    name = name_list[a]
    x = np.arange(2.5, 1.2 * Q / (1 - l), 0.02)
    sns.set_style('darkgrid')

    # %%
    NP = 50  # 初始化种群数
    L = 20  # 二进制位串长度
    Pc = 0.8  # 交叉率
    Pm = 0.3  # 变异率
    G = 200  # 最大遗传代数
    Xs = 1.2 * Q / (1 - l)  # 上限
    Xx = 2.5  # 下限
    f = np.random.randint(0, high=2, size=(NP, L))  # 生成随机初始种群
    fit = np.zeros((1, 100))[0].tolist()
    x = np.zeros((1, 100))[0].tolist()
    trace = []
    xtrace = []
    # %%遗传算法循环
    for i in range(G):
        nf = f
        for M in range(0, NP, 2):
            p = np.random.rand()  # 交叉
            if p < Pc:
                q = np.random.randint(0, high=2, size=(1, L))[0].tolist()
                for j in range(L):
                    if q[j] == 1:
                        temp = nf[M + 1][j]
                        nf[M + 1][j] = nf[M][j]
                        nf[M][j] = temp
        j = 1
        while j <= (NP * Pm):
            h = np.random.randint(1, high=NP)  # 变异
            for k in range(round(L * Pm)):
                g = np.random.randint(1, high=L)
                nf[h][g] = (not nf[h][g]) + 0  # 取反操作，python和matlab不一样
            j += 1
        # 交叉变异结束之后，新一代nf加上前代f共2*NP个个体进行筛选
        newf = np.vstack((f, nf))
        for j in range(newf.shape[0]):
            U = newf[j]
            m = 0
            for k in range(L):
                m = U[k] * (2 ** (k - 1)) + m  # 将二进制解码为定义域范围内十进制
            x[j] = Xx + m * (Xs - Xx) / (2 ** (L - 1))
            fit[j] = funcl(x[j], w, F)  # 适应度函数
        maxfit = max(fit)
        minfit = min(fit)
        if maxfit == minfit:
            break
        rr = fit.index(maxfit)
        fbest = f[rr]
        xbest = x[rr]
        Fit = (np.array(fit) - minfit) / (maxfit - minfit)
        sum_Fit = sum(Fit)  # 概率筛选复制操作（不是简单的复制，我们是根据适应函数给导向的）
        Pfit = Fit / sum_Fit
        indexnf = np.arange(0, 100).tolist()
        ng = []
        for dex in range(NP):
            ng.append(np.random.choice(indexnf, p=Pfit))
        for j in range(NP):
            f[j] = newf[ng[j]]
        f[0] = fbest
        trace.append(maxfit)
        xtrace.append(xbest)

    sum_1 = sum_1 + max(trace)
    print(f'{name}单品的利润：')
    print(max(trace))
    print(f'{name}单品的补货量：')
    print(max(xtrace))
    #print(F)
    print(f'{name}单品的定价：')
    print((w / (1 - l)) * (1 + F))
    # 创建每次迭代的数据框
    iteration_df = pd.DataFrame({
        '单品名称': [name],
        '利润': [max(trace)],
        '补货量': [max(xtrace)],
        '定价': [(w / (1 - l)) * (1 + F)]
    })
    # 将数据框追加到整体结果数据框中
    result_df = pd.concat([result_df, iteration_df], ignore_index=True)
print('总利润为：')
print(sum_1)

result_df.to_excel('E:\\数据科学\\2023年秋数据科学导论大作业数据\\附件3_项目三数据集\\result_df_第三问1.xlsx', index=False)

'''
Q = eval(input())
w = eval(input())
F = eval(input())
l = eval(input())
x = np.arange(2.5, 1.2*Q/(1-l), 0.02)
sns.set_style('darkgrid')
def funcl(x,w,f):
    y = x*w*f
    return y
# %%
NP = 50  # 初始化种群数
L = 20  # 二进制位串长度
Pc = 0.8  # 交叉率
Pm = 0.3  # 变异率
G = 200  # 最大遗传代数
Xs = 1.2*Q/(1-l) # 上限
Xx = 2.5  # 下限
f = np.random.randint(0, high=2, size=(NP, L))  # 生成随机初始种群
fit = np.zeros((1, 100))[0].tolist()
x = np.zeros((1, 100))[0].tolist()
trace = []
xtrace = []
# %%遗传算法循环
for i in range(G):
    nf = f
    for M in range(0, NP, 2):
        p = np.random.rand()  # 交叉
        if p < Pc:
            q = np.random.randint(0, high=2, size=(1, L))[0].tolist()
            for j in range(L):
                if q[j] == 1:
                    temp = nf[M + 1][j]
                    nf[M + 1][j] = nf[M][j]
                    nf[M][j] = temp
    j = 1
    while j <= (NP * Pm):
        h = np.random.randint(1, high=NP)  # 变异
        for k in range(round(L * Pm)):
            g = np.random.randint(1, high=L)
            nf[h][g] = (not nf[h][g]) + 0  # 取反操作，python和matlab不一样
        j += 1
    # 交叉变异结束之后，新一代nf加上前代f共2*NP个个体进行筛选
    newf = np.vstack((f, nf))
    for j in range(newf.shape[0]):
        U = newf[j]
        m = 0
        for k in range(L):
            m = U[k] * (2 ** (k - 1)) + m  # 将二进制解码为定义域范围内十进制
        x[j] = Xx + m * (Xs - Xx) / (2 ** (L - 1))
        fit[j] = funcl(x[j],w,F)  # 适应度函数
    maxfit = max(fit)
    minfit = min(fit)
    if maxfit == minfit:
        break
    rr = fit.index(maxfit)
    fbest = f[rr]
    xbest = x[rr]
    Fit = (np.array(fit) - minfit) / (maxfit - minfit)
    sum_Fit = sum(Fit)  # 概率筛选复制操作（不是简单的复制，我们是根据适应函数给导向的）
    Pfit = Fit / sum_Fit
    indexnf = np.arange(0, 100).tolist()
    ng = []
    for dex in range(NP):
        ng.append(np.random.choice(indexnf, p=Pfit))
    for j in range(NP):
        f[j] = newf[ng[j]]
    f[0] = fbest
    trace.append(maxfit)
    xtrace.append(xbest)

print(max(trace))
print(max(xtrace))
print(F)
print((w/(1-l))*(1+F))
'''
