import pandas as pd
import random
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import r2_score

# 定义函数来检测和删除异常值
def remove_outliers(df, column, threshold=3):
    z_scores = np.abs((df[column] - df[column].mean()) / df[column].std())
    df_no_outliers = df[z_scores < threshold]
    return df_no_outliers

df = pd.read_excel("E:\数据科学\\2023年秋数据科学导论大作业数据\附件3_项目三数据集\merged_data_1234.xlsx")


df_1_pl1 = df[df['分类编码'] == 1011010101]
df_1_pl2 = df[df['分类编码'] == 1011010201]
df_1_pl3 = df[df['分类编码'] == 1011010402]
df_1_pl4 = df[df['分类编码'] == 1011010501]
df_1_pl5 = df[df['分类编码'] == 1011010504]
df_1_pl6 = df[df['分类编码'] == 1011010801]

# 按分类编码分组
grouped_df = df.groupby('分类编码')


# 循环遍历每个商品的相关系数
for code, group_df in grouped_df:
    if code in [1011010101, 1011010201, 1011010402, 1011010501, 1011010504, 1011010801]:

        group_df = group_df[group_df['销售类型'] == '销售']
        group_df = group_df[group_df['是否打折销售'] == '否']

        # 合并每天的销售量和其他数据
        daily_sales = group_df.groupby('销售日期').agg({
            '销量(千克)': 'sum',
            '批发价格(元/千克)': 'mean',
            '销售单价(元/千克)': 'mean',
        }).reset_index()

        # 循环遍历不同日期范围
        for start_date, end_date in [('2020-07-01', '2023-06-30'), ('2022-02-01', '2023-06-30'),
                                     ('2022-04-01', '2023-06-30'), ('2022-06-01', '2023-06-30'),
                                     ('2022-08-01', '2023-06-30'), ('2022-10-01', '2023-06-30'),
                                     ('2022-12-01', '2023-06-30'),
                                     ('2023-01-01', '2023-06-30'), ('2023-02-01', '2023-06-30'),
                                     ('2023-03-01', '2023-06-30'),
                                     ('2023-04-01', '2023-06-30'), ('2023-05-01', '2023-06-30'),
                                     ('2023-06-01', '2023-06-30')]:
            yearly_data = daily_sales[(daily_sales['销售日期'] >= start_date) & (daily_sales['销售日期'] <= end_date)]

            # 删除 '销量(千克)' 列的异常值，阈值可以根据需要调整
            yearly_data = remove_outliers(yearly_data, '销量(千克)')

            # 计算相关系数
            correlation_coefficient = yearly_data['销量(千克)'].corr(yearly_data['销售单价(元/千克)'])

            # 打印结果或进行其他操作
            print(
                f'商品分类编码 {code} 在日期范围 {start_date} 到 {end_date} 的销量(千克)和销售单价相关系数: {correlation_coefficient}')

            features = yearly_data[['销售单价(元/千克)']]
            target = yearly_data['销量(千克)']

            # 将数据分为训练集和测试集
            X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

            # 创建并训练线性回归模型
            model = LinearRegression()
            model.fit(X_train, y_train)

            # 在测试集上进行预测
            y_pred = model.predict(X_test)

            # 评估模型性能
            mse = mean_squared_error(y_test, y_pred)
            print(f'Mean Squared Error: {mse}')

            # 均方根误差（Root Mean Squared Error, RMSE）
            rmse = np.sqrt(mse)
            print(f'Root Mean Squared Error: {rmse}')

            # 平均绝对误差（Mean Absolute Error, MAE）
            mae = mean_absolute_error(y_test, y_pred)
            print(f'Mean Absolute Error: {mae}')

            # 决定系数（Coefficient of Determination, R^2）
            r2 = r2_score(y_test, y_pred)
            print(f'R^2 Score: {r2}')

            # 打印线性回归模型的系数和截距
            print(f'截距 (Intercept): {model.intercept_}')
            print(f'系数 (Coefficients): {model.coef_}')

            # 打印线性回归模型的公式
            formula = f'销售量 = {model.intercept_:.4f} + '
            for i, coef in enumerate(model.coef_):
                formula += f'{coef:.4f} * {features.columns[i]}'
                if i < len(model.coef_) - 1:
                    formula += ' + '

            print('线性回归公式:', formula)

min = 5
max = 0
# 循环遍历每个商品的相关系数
for code, group_df in grouped_df:
    if code in [1011010101, 1011010201, 1011010402, 1011010501, 1011010504, 1011010801]:

        group_df = group_df[group_df['销售类型'] == '销售']
        group_df = group_df[group_df['是否打折销售'] == '否']

        # 合并每天的销售量和其他数据
        daily_sales = group_df.groupby('销售日期').agg({
            '销量(千克)': 'sum',
            '批发价格(元/千克)': 'mean',
            '销售单价(元/千克)': 'mean',
        }).reset_index()

        # 循环遍历不同日期范围
        for start_date, end_date in [('2020-07-01', '2023-06-30'),('2022-02-01', '2023-06-30'),('2022-04-01', '2023-06-30'),('2022-06-01', '2023-06-30'),
                                     ('2022-08-01', '2023-06-30'),('2022-10-01', '2023-06-30'),('2022-12-01', '2023-06-30'),
                                     ('2023-01-01', '2023-06-30'),('2023-02-01', '2023-06-30'), ('2023-03-01', '2023-06-30'),
                                     ('2023-04-01', '2023-06-30'),('2023-05-01', '2023-06-30'),('2023-06-01', '2023-06-30')]:
            yearly_data = daily_sales[(daily_sales['销售日期'] >= start_date) & (daily_sales['销售日期'] <= end_date)]

            # 删除 '销量(千克)' 列的异常值，阈值可以根据需要调整
            #yearly_data = remove_outliers(yearly_data, '销量(千克)')

            # 计算相关系数
            correlation_coefficient = yearly_data['批发价格(元/千克)'].corr(yearly_data['销售单价(元/千克)'])

            # 打印结果或进行其他操作
            print(f'商品分类编码 {code} 在日期范围 {start_date} 到 {end_date} 的批发价格(元/千克)和销售单价相关系数: {correlation_coefficient}')
            
            features = yearly_data[['批发价格(元/千克)']]
            target = yearly_data['销售单价(元/千克)']

            # 将数据分为训练集和测试集
            X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

            # 创建并训练线性回归模型
            model = LinearRegression()
            model.fit(X_train, y_train)

            # 在测试集上进行预测
            y_pred = model.predict(X_test)

            # 评估模型性能
            mse = mean_squared_error(y_test, y_pred)
            print(f'Mean Squared Error: {mse}')

            # 均方根误差（Root Mean Squared Error, RMSE）
            rmse = np.sqrt(mse)
            print(f'Root Mean Squared Error: {rmse}')

            # 平均绝对误差（Mean Absolute Error, MAE）
            mae = mean_absolute_error(y_test, y_pred)
            print(f'Mean Absolute Error: {mae}')

            # 决定系数（Coefficient of Determination, R^2）
            r2 = r2_score(y_test, y_pred)
            print(f'R^2 Score: {r2}')

            # 打印线性回归模型的系数和截距
            print(f'截距 (Intercept): {model.intercept_}')
            print(f'系数 (Coefficients): {model.coef_}')

            # 打印线性回归模型的公式
            formula = f'销售单价 = {model.intercept_:.4f} + '
            for i, coef in enumerate(model.coef_):
                formula += f'{coef:.4f} * {features.columns[i]}'
                if i < len(model.coef_) - 1:
                    formula += ' + '

            print('线性回归公式:', formula)

            if(model.coef_< min):
                min = model.coef_
            if(model.coef_>max):
                max = model.coef_
            print('系数最小为',min)
            print('系数最大为',max)



# 循环遍历每个商品的相关系数
for code, group_df in grouped_df:
    if code in [1011010101, 1011010201, 1011010402, 1011010501, 1011010504, 1011010801]:

        group_df = group_df[group_df['销售类型'] == '销售']
        group_df = group_df[group_df['是否打折销售'] == '否']

        # 合并每天的销售量和其他数据
        daily_sales = group_df.groupby('销售日期').agg({
            '销量(千克)': 'sum',
            '批发价格(元/千克)': 'mean',
            '销售单价(元/千克)': 'mean',
        }).reset_index()

        # 删除 '销量(千克)' 列的异常值，阈值可以根据需要调整
        # yearly_data = remove_outliers(yearly_data, '销量(千克)')

        # 计算相关系数
        correlation_coefficient = daily_sales['批发价格(元/千克)'].corr(daily_sales['销售单价(元/千克)'])

        # 打印结果或进行其他操作
        print(f'批发价格(元/千克)和销售单价相关系数: {correlation_coefficient}')

        features = daily_sales[['批发价格(元/千克)']]
        target = daily_sales['销售单价(元/千克)']

        # 将数据分为训练集和测试集
        X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

        # 创建并训练线性回归模型
        model = LinearRegression()
        model.fit(X_train, y_train)

        # 在测试集上进行预测
        y_pred = model.predict(X_test)

        # 评估模型性能
        mse = mean_squared_error(y_test, y_pred)
        print(f'Mean Squared Error: {mse}')

        # 均方根误差（Root Mean Squared Error, RMSE）
        rmse = np.sqrt(mse)
        print(f'Root Mean Squared Error: {rmse}')

        # 平均绝对误差（Mean Absolute Error, MAE）
        mae = mean_absolute_error(y_test, y_pred)
        print(f'Mean Absolute Error: {mae}')

        # 决定系数（Coefficient of Determination, R^2）
        r2 = r2_score(y_test, y_pred)
        print(f'R^2 Score: {r2}')

        # 打印线性回归模型的系数和截距
        print(f'截距 (Intercept): {model.intercept_}')
        print(f'系数 (Coefficients): {model.coef_}')


        # 打印线性回归模型的公式
        formula = f'销售单价 = {model.intercept_:.4f} + '
        for i, coef in enumerate(model.coef_):
            formula += f'{coef:.4f} * {features.columns[i]}'
            if i < len(model.coef_) - 1:
                formula += ' + '

        print('线性回归公式:', formula)




'''
# 绘制散点图
plt.scatter(features, target)
plt.title('Sales Quantity vs. Unit Price')
plt.xlabel('Sales Quantity ')
plt.ylabel('Unit Price ')
plt.show()


# 将数据分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

# 创建并训练线性回归模型
model = LinearRegression()
model.fit(X_train, y_train)

# 在测试集上进行预测
y_pred = model.predict(X_test)

# 评估模型性能
mse = mean_squared_error(y_test, y_pred)
print(f'Mean Squared Error: {mse}')
'''
'''
# 假设data是包含销售数据的DataFrame
# 选择特征和目标变量
features = df_pl_hueye[['销量(千克)', '批发价格(元/千克)', '损耗率(%)']]
target = df_pl_hueye['销售单价(元/千克)']

# 将数据分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

# 使用多项式回归进行特征转换
degree = 2  # 多项式的次数，可以根据数据的复杂性进行调整
poly = PolynomialFeatures(degree=degree)
X_train_poly = poly.fit_transform(X_train)
X_test_poly = poly.transform(X_test)

# 创建并训练多项式回归模型
model = LinearRegression()
model.fit(X_train_poly, y_train)

# 在测试集上进行预测
y_pred = model.predict(X_test_poly)
'''
'''
# 评估模型性能
mse = mean_squared_error(y_test, y_pred)
print(f'Mean Squared Error: {mse}')

# 均方根误差（Root Mean Squared Error, RMSE）
rmse = np.sqrt(mse)
print(f'Root Mean Squared Error: {rmse}')

# 平均绝对误差（Mean Absolute Error, MAE）
mae = mean_absolute_error(y_test, y_pred)
print(f'Mean Absolute Error: {mae}')

# 决定系数（Coefficient of Determination, R^2）
r2 = r2_score(y_test, y_pred)
print(f'R^2 Score: {r2}')

# 可视化实际值和预测值的比较
plt.scatter(y_test, y_pred)
plt.xlabel('Actual Selling Price (CNY/Kg)')
plt.ylabel('Predicted Selling Price (CNY/Kg)')
plt.title('Actual vs Predicted Values')
plt.show()

# 打印线性回归模型的系数和截距
print(f'截距 (Intercept): {model.intercept_}')
print(f'系数 (Coefficients): {model.coef_}')


# 打印线性回归模型的公式
formula = f'销售单价 = {model.intercept_:.4f} + '
for i, coef in enumerate(model.coef_):
    formula += f'{coef:.4f} * {features.columns[i]}'
    if i < len(model.coef_) - 1:
        formula += ' + '

print('线性回归公式:', formula)
'''

'''
# 打印模型公式
formula = f'{model.intercept_:.4f}'

feature_names = poly.get_feature_names_out(features.columns)
for i in range(len(feature_names)):
    coef = model.coef_[i]
    if coef != 0:
        formula += f' + {coef:.4f} * {feature_names[i]}'

print(f'多项式回归公式: {formula}')
'''

