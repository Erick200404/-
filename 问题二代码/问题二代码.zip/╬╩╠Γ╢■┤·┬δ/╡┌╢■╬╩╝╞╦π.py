import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


def funcl(x, k, b, l, f):
    y = ((x**2)*((1-l)**2)-b*x*(1-l))/k-((x**2)*(1-l)-x*b)/(k*(1+f))
    return y
Q_m = pd.read_excel("E:\数据科学\\2023年秋数据科学导论大作业数据\附件3_项目三数据集\\2forecast_values.xlsx")
Q_m = Q_m.set_index('天数')  # 将 "天数" 列设置为索引
Q_m = Q_m.values
#print(Q_m.shape)
#print(Q_m[1][4])

l_m = pd.read_excel("E:\数据科学\\2023年秋数据科学导论大作业数据\附件3_项目三数据集\附件4.xlsx" )
l_m = l_m.sort_values(by='小分类编码')
l_m = l_m['平均损耗率(%)_小分类编码_不同值']
l_m = l_m.values
#print(l_m)
kb_m = pd.read_excel("E:\数据科学\\2023年秋数据科学导论大作业数据\附件3_项目三数据集\不同品类的销售量与销售单价的关系.xlsx")
k_m = kb_m['斜率']
b_m = kb_m['截距']
k_m = k_m.values
b_m = b_m.values
#print(k_m)
#print(b_m)

F_m = pd.read_excel("E:\数据科学\\2023年秋数据科学导论大作业数据\附件3_项目三数据集\利润率.xlsx")
F_m = F_m['利润率']
F_m = F_m.values
#print(F_m)

sum_1 = 0
# 初始化一个空的数据框
result_df = pd.DataFrame(columns=['品类', '天', '利润', '补货量','定价'])

for a in range(6):
    for o in range(7):

        Q = Q_m[o][a]
        l = l_m[a]/100
        K = k_m[a]
        b = b_m[a]
        F = F_m[a]
        #print(Q)
        #print(l)
        #print(K)
        #print(b)
        #print(F)


        x = np.arange(0.8 * Q / (1 - l), 1.2 * Q / (1 - l), 0.02)
        sns.set_style('darkgrid')

        # %%
        NP = 50  # 初始化种群数
        L = 20  # 二进制位串长度
        Pc = 0.8  # 交叉率
        Pm = 0.3  # 变异率
        G = 200  # 最大遗传代数
        Xs = 1.2 * Q / (1 - l)  # 上限
        Xx = 0.8 * Q / (1 - l)  # 下限
        f = np.random.randint(0, high=2, size=(NP, L))  # 生成随机初始种群
        fit = np.zeros((1, 100))[0].tolist()
        x = np.zeros((1, 100))[0].tolist()
        trace = []
        xtrace = []
        # %%遗传算法循环
        for i in range(G):
            nf = f
            for M in range(0, NP, 2):
                p = np.random.rand()  # 交叉
                if p < Pc:
                    q = np.random.randint(0, high=2, size=(1, L))[0].tolist()
                    for j in range(L):
                        if q[j] == 1:
                            temp = nf[M + 1][j]
                            nf[M + 1][j] = nf[M][j]
                            nf[M][j] = temp
            j = 1
            while j <= (NP * Pm):
                h = np.random.randint(1, high=NP)  # 变异
                for k in range(round(L * Pm)):
                    g = np.random.randint(1, high=L)
                    nf[h][g] = (not nf[h][g]) + 0  # 取反操作，python和matlab不一样
                j += 1
            # 交叉变异结束之后，新一代nf加上前代f共2*NP个个体进行筛选
            newf = np.vstack((f, nf))
            for j in range(newf.shape[0]):
                U = newf[j]
                m = 0
                for k in range(L):
                    m = U[k] * (2 ** (k - 1)) + m  # 将二进制解码为定义域范围内十进制
                x[j] = Xx + m * (Xs - Xx) / (2 ** (L - 1))
                fit[j] = funcl(x[j], K, b, l, F)  # 适应度函数
            maxfit = max(fit)
            minfit = min(fit)
            if maxfit == minfit:
                break
            rr = fit.index(maxfit)
            fbest = f[rr]
            xbest = x[rr]
            Fit = (np.array(fit) - minfit) / (maxfit - minfit)
            sum_Fit = sum(Fit)  # 概率筛选复制操作（不是简单的复制，我们是根据适应函数给导向的）
            Pfit = Fit / sum_Fit
            indexnf = np.arange(0, 100).tolist()
            ng = []
            for dex in range(NP):
                ng.append(np.random.choice(indexnf, p=Pfit))
            for j in range(NP):
                f[j] = newf[ng[j]]
            f[0] = fbest
            trace.append(maxfit)
            xtrace.append(xbest)

        print(f'第{a+1}品类，第{o+1}天的利润：')
        print(max(trace))
        print(f'第{a+1}品类，第{o+1}天的补货量：')
        print(max(xtrace))
        #print(b)
        #print(K)
        print(f'第{a+1}品类，第{o+1}天的定价：')
        print((max(xtrace) * (1 - l) - b) / K)

        # 创建每次迭代的数据框
        iteration_df = pd.DataFrame({
            '品类': [a + 1],
            '天': [o + 1],
            '利润': [max(trace)],
            '补货量': [max(xtrace)],
            '定价': [((max(xtrace) * (1 - l) - b) / K)]
        })
        # 将数据框追加到整体结果数据框中
        result_df = pd.concat([result_df, iteration_df], ignore_index=True)
        sum_1 = sum_1 + max(trace)
print('总利润为：')
print(sum_1)

result_df.to_excel('E:\\数据科学\\2023年秋数据科学导论大作业数据\\附件3_项目三数据集\\result_df.xlsx', index=False)
'''
Q = eval(input())
l = eval(input())
K = eval(input())
b = eval(input())

x = np.arange(0.8*Q/(1-l), 1.2*Q/(1-l), 0.02)
sns.set_style('darkgrid')
def funcl(x, k, b, l):
    y = ((x**2)*((1-l)**2)-b*x*(1-l))/k
    return y
# %%
NP = 50  # 初始化种群数
L = 20  # 二进制位串长度
Pc = 0.8  # 交叉率
Pm = 0.3  # 变异率
G = 200  # 最大遗传代数
Xs = 1.2*Q/(1-l)  # 上限
Xx = 0.8*Q/(1-l)  # 下限
f = np.random.randint(0, high=2, size=(NP, L))  # 生成随机初始种群
fit = np.zeros((1, 100))[0].tolist()
x = np.zeros((1, 100))[0].tolist()
trace = []
xtrace = []
# %%遗传算法循环
for i in range(G):
    nf = f
    for M in range(0, NP, 2):
        p = np.random.rand()  # 交叉
        if p < Pc:
            q = np.random.randint(0, high=2, size=(1, L))[0].tolist()
            for j in range(L):
                if q[j] == 1:
                    temp = nf[M + 1][j]
                    nf[M + 1][j] = nf[M][j]
                    nf[M][j] = temp
    j = 1
    while j <= (NP * Pm):
        h = np.random.randint(1, high=NP)  # 变异
        for k in range(round(L * Pm)):
            g = np.random.randint(1, high=L)
            nf[h][g] = (not nf[h][g]) + 0  # 取反操作，python和matlab不一样
        j += 1
    # 交叉变异结束之后，新一代nf加上前代f共2*NP个个体进行筛选
    newf = np.vstack((f, nf))
    for j in range(newf.shape[0]):
        U = newf[j]
        m = 0
        for k in range(L):
            m = U[k] * (2 ** (k - 1)) + m  # 将二进制解码为定义域范围内十进制
        x[j] = Xx + m * (Xs - Xx) / (2 ** (L - 1))
        fit[j] = funcl(x[j], K, b, l)  # 适应度函数
    maxfit = max(fit)
    minfit = min(fit)
    if maxfit == minfit:
        break
    rr = fit.index(maxfit)
    fbest = f[rr]
    xbest = x[rr]
    Fit = (np.array(fit) - minfit) / (maxfit - minfit)
    sum_Fit = sum(Fit)  # 概率筛选复制操作（不是简单的复制，我们是根据适应函数给导向的）
    Pfit = Fit / sum_Fit
    indexnf = np.arange(0, 100).tolist()
    ng = []
    for dex in range(NP):
        ng.append(np.random.choice(indexnf, p=Pfit))
    for j in range(NP):
        f[j] = newf[ng[j]]
    f[0] = fbest
    trace.append(maxfit)
    xtrace.append(xbest)

print(max(trace))
print(max(xtrace))
print(b)
print(K)
print((max(xtrace)*(1-l)-b)/K)
plt.plot(trace, color='green', marker='o', linewidth=2, markersize=3)
plt.xlabel('Number of iterations', fontsize=10)
plt.ylabel('maxyvalue', fontsize=10)
plt.savefig('pic3', bbox_inches='tight', pad_inches=0, dpi=350)
plt.close()

plt.plot(xtrace, color='m', marker='o', linewidth=2, markersize=3)
plt.xlabel('Number of iterations', fontsize=10)
plt.ylabel('Corresponding xvalue', fontsize=10)
plt.savefig('pic2', bbox_inches='tight', pad_inches=0, dpi=350)
plt.close()
'''
